class BedRoomObjects {
    let name: String
    let isEletronic: Bool
    let size: Double
    let material: String
    
    init(name: String, isEletronic: Bool, size: Double, material: String) {
        self.name = name
        self.isEletronic = isEletronic
        self.size = size
        self.material = material
    }
    
    func construct() {
        print("O objeto vai ser construido \(name)")
    }
}

class BedRoomObjectsNotEletronic: BedRoomObjects {
    init(name: String, size: Double, material: String) {
        super.init(name: name, isEletronic: false, size: size, material: material)
    }
    
    func waterResistence() {
        print("Resistiu a água")
    }
    
    override func construct() {
        super.construct()
        print("\(name) foi montado")
    }
}

class BedRoomObjectsEletronic: BedRoomObjects {
    init(name: String, size: Double, material: String) {
        super.init(name: name, isEletronic: true, size: size, material: material)
    }
    
    func turnOn() {
        print("Ligou o objeto \(name)")
    }
    
    override func construct() {
        super.construct()
        print("\(name) foi instalada")
    }
}

let bed = BedRoomObjectsNotEletronic(name: "Cama", size: 1.80, material: "Madeira")
bed.construct()

let wardrobe = BedRoomObjectsNotEletronic(name: "Guarda-Roupa", size: 1.90, material: "Madeira")
wardrobe.construct()
wardrobe.waterResistence()
print("é eletronico \(wardrobe.isEletronic)")

let television = BedRoomObjectsEletronic(name: "Televisão", size: 1.30, material: "Alumínio")
television.construct()
television.turnOn()
print("é eletronico \(television.isEletronic)")
