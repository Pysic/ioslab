// Criar classe generica de Desenvolvedor (3 propriedades e 2 funçoes)
// Pelo menos 1 propriedade ser optional
// 1 funcao que trabalhe o optional
// Criar uma segunda classe de desenvolvedor especifica, herdando da classe Desenvolvedor
// Criar 1 nova func, 1 novo parametro, sobreescrever pelo menos 1 metodo da classe pai


class Animal {
    let name: String?
    let haveFangs: Bool
    let isFlight: Bool
    
    init(name: String? = nil, haveFangs: Bool, isFlight: Bool) {
        self.name = name
        self.haveFangs = haveFangs
        self.isFlight = isFlight
        print("Foi inicializado")
    }
    
    func eat(food: String) {
        if let name {
            print("O \(name) comeu a \(food)")
            return
        }
        
        print("Comeu a \(food)")
    }
}

class FlightAnimal: Animal {
    init(name: String? = nil, haveFangs: Bool) {
        super.init(name: name, haveFangs: haveFangs, isFlight: true)
    }
    
    func fly() {
        print("Estou voando")
    }
    
    override func eat(food: String) {
        super.eat(food: food)
        print("Jogou parte fora")
    }
}

class VenomousAnimal: Animal {
    let inoculatePoison: Bool
    
    init(name: String? = nil, isFlight: Bool, inoculatePoison: Bool) {
        self.inoculatePoison = inoculatePoison
        super.init(name: name, haveFangs: true, isFlight: isFlight)
    }
    
    func attack() {
        if inoculatePoison {
            print("Inoculou veneno no alvo")
        } else {
            print("Atacou o alvo")
        }
        
    }
    
    override func eat(food: String) {
        super.eat(food: food)
        print("E descansou")
    }
}

let lion = Animal(haveFangs: true, isFlight: false)
let bird = FlightAnimal(haveFangs: false)
let snake = VenomousAnimal(isFlight: false, inoculatePoison: false)

lion.eat(food: "zebra")
bird.eat(food: "ração")
snake.eat(food: "coelho")
snake.attack()
