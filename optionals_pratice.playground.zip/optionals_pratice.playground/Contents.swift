var nameReceived: String
var numberReceived: Int
var boolReceived: Bool
var nameTwoReceived: String
var numberTwoReceived: Float
var numberThreeReceived: Double

let name: String? = nil
let number: Int? = 204
let bool: Bool? = false
let nameTwo: String? = "Maria"
let numberTwo: String? = "2.4"
let numberThree: Int? = 4

// ------------------------------------------- //

nameReceived = name ?? "Pedro"
print(nameReceived)

if let nameUnwrap = name {
    nameReceived = nameUnwrap
    print(nameReceived)
}

func guardName(){
    guard let nameUnwrap = name else {
        return
    }
    nameReceived = nameUnwrap
    print(nameReceived)
}
guardName()
